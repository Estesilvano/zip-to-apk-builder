/* ============================================================
   Data - Carrega e gerencia o Novo Testamento
   ============================================================ */
const Data = (() => {
    let _nt = null;       // Array de livros em ordem cronológica
    let _byAbbrev = {};   // Cache por abbrev
    let _loaded = false;

    async function load() {
        if (_loaded) return _nt;
        try {
            const resp = await fetch('data/nt_cronologico.json');
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            _nt = await resp.json();
            _nt.forEach(b => { _byAbbrev[b.abbrev] = b; });
            _loaded = true;
            console.log('NT carregado:', _nt.length, 'livros');
            return _nt;
        } catch (e) {
            console.error('Falha ao carregar NT:', e);
            throw e;
        }
    }

    function getAll() { return _nt || []; }

    function getBook(abbrev) { return _byAbbrev[abbrev] || null; }

    function getChapter(abbrev, chapter) {
        const b = getBook(abbrev);
        if (!b) return null;
        const idx = parseInt(chapter) - 1;
        if (idx < 0 || idx >= b.chapters.length) return null;
        return b.chapters[idx];
    }

    function getVerse(abbrev, chapter, verse) {
        const c = getChapter(abbrev, chapter);
        if (!c) return null;
        const idx = parseInt(verse) - 1;
        return c[idx] || null;
    }

    function getNeighbors(abbrev, chapter) {
        const all = getAll();
        const bIdx = all.findIndex(b => b.abbrev === abbrev);
        if (bIdx < 0) return { prev: null, next: null };
        const book = all[bIdx];
        const c = parseInt(chapter);

        let prev = null, next = null;
        if (c > 1) prev = { abbrev, chapter: c - 1, nome: book.nome };
        else if (bIdx > 0) {
            const pb = all[bIdx - 1];
            prev = { abbrev: pb.abbrev, chapter: pb.chapters.length, nome: pb.nome };
        }
        if (c < book.chapters.length) next = { abbrev, chapter: c + 1, nome: book.nome };
        else if (bIdx < all.length - 1) {
            const nb = all[bIdx + 1];
            next = { abbrev: nb.abbrev, chapter: 1, nome: nb.nome };
        }
        return { prev, next };
    }

    // Versículo do dia (determinístico por dia)
    function getVerseOfDay() {
        const all = getAll();
        if (!all.length) return null;
        const today = new Date();
        const dayKey = today.getFullYear() * 1000 + (today.getMonth()+1)*50 + today.getDate();
        // Lista curada de referências marcantes
        const refs = [
            ['jo', 3, 16], ['rm', 8, 28], ['fp', 4, 13], ['jo', 14, 6],
            ['mt', 11, 28], ['hb', 11, 1], ['rm', 12, 2], ['ef', 2, 8],
            ['gl', 5, 22], ['1co', 13, 4], ['mt', 6, 33], ['tg', 1, 5],
            ['ap', 21, 4], ['fp', 4, 6], ['1jo', 4, 8], ['mt', 5, 16],
            ['rm', 10, 9], ['1pe', 5, 7], ['hb', 13, 8], ['jo', 8, 32],
            ['1ts', 5, 16], ['cl', 3, 23], ['2tm', 1, 7], ['mt', 28, 19],
            ['lc', 6, 31], ['at', 1, 8], ['gl', 2, 20], ['ef', 6, 11],
            ['fm', 1, 6], ['tg', 4, 7]
        ];
        const ref = refs[dayKey % refs.length];
        const verseText = getVerse(ref[0], ref[1], ref[2]);
        const book = getBook(ref[0]);
        if (!verseText || !book) return null;
        return {
            abbrev: ref[0],
            chapter: ref[1],
            verse: ref[2],
            text: verseText,
            ref: `${book.nome} ${ref[1]}:${ref[2]}`
        };
    }

    return {
        load, getAll, getBook, getChapter, getVerse, getNeighbors, getVerseOfDay,
        isLoaded: () => _loaded
    };
})();
