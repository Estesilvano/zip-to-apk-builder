/* ============================================================
   Search - Busca em todo o NT (texto + referências)
   ============================================================ */
const Search = (() => {

    // Remove acentos para busca insensível
    function normalize(s) {
        return (s || '').toString().toLowerCase()
            .normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    }

    // Tenta interpretar query como referência: "joão 3:16", "jo 3", "rm 8 28"
    function parseReference(q) {
        const all = Data.getAll();
        const m = q.trim().match(/^([1-3]?\s*[a-zçãáéíóúâêô\u00C0-\u017F]+)\s*(\d+)?\s*[:.,]?\s*(\d+)?$/i);
        if (!m) return null;
        const nameQ = normalize(m[1]).replace(/\s+/g, '');
        const ch = m[2] ? parseInt(m[2]) : null;
        const vs = m[3] ? parseInt(m[3]) : null;

        const book = all.find(b => {
            const n = normalize(b.nome).replace(/\s+/g, '');
            const ab = normalize(b.abbrev);
            return n === nameQ || n.startsWith(nameQ) || ab === nameQ;
        });
        if (!book) return null;
        return { book, chapter: ch, verse: vs };
    }

    function highlight(text, queryTerms) {
        let out = text;
        queryTerms.forEach(t => {
            if (t.length < 2) return;
            const safe = t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
            const regex = new RegExp(`(${safe})`, 'gi');
            out = out.replace(regex, '<mark>$1</mark>');
        });
        return out;
    }

    // Busca textual no NT
    function searchText(query, limit = 200) {
        const q = normalize(query.trim());
        if (q.length < 2) return [];
        const terms = q.split(/\s+/).filter(t => t.length >= 2);
        const results = [];

        const all = Data.getAll();
        for (const book of all) {
            for (let ci = 0; ci < book.chapters.length; ci++) {
                const chapter = book.chapters[ci];
                for (let vi = 0; vi < chapter.length; vi++) {
                    const verseText = chapter[vi];
                    const norm = normalize(verseText);
                    // Todos os termos precisam aparecer
                    if (terms.every(t => norm.includes(t))) {
                        results.push({
                            abbrev: book.abbrev,
                            nome: book.nome,
                            chapter: ci + 1,
                            verse: vi + 1,
                            text: verseText,
                            highlighted: highlight(verseText, terms),
                            ref: `${book.nome} ${ci+1}:${vi+1}`
                        });
                        if (results.length >= limit) return results;
                    }
                }
            }
        }
        return results;
    }

    return { searchText, parseReference, normalize, highlight };
})();
