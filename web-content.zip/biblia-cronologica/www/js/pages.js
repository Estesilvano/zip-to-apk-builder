/* ============================================================
   Pages - Renderização de todas as páginas/telas
   ============================================================ */
const Pages = (() => {

    const $ = (sel, root = document) => root.querySelector(sel);
    const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
    const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

    function setTitle(t) { const el = $('#topbarTitle'); if (el) el.textContent = t; }

    // ============ HOME ============
    function home() {
        setTitle('Bíblia Cronológica');
        const lastRead = Storage.getLastRead();
        const vod = Data.getVerseOfDay();
        let lastReadHTML = '';
        if (lastRead) {
            const book = Data.getBook(lastRead.abbrev);
            if (book) {
                lastReadHTML = `
                <div class="continue-card" onclick="Router.go('/chapter/${lastRead.abbrev}/${lastRead.chapter}')">
                    <div class="label">Continuar leitura</div>
                    <div class="title">${esc(book.nome)} ${lastRead.chapter}</div>
                    <div class="meta">${esc(book.ano)} • ${esc(book.autor)}</div>
                </div>`;
            }
        }

        const vodHTML = vod ? `
            <div class="verse-of-day">
                "${esc(vod.text)}"
                <div class="verse-of-day-ref">— ${esc(vod.ref)}</div>
            </div>` : '';

        return `
            <div class="home-hero">
                <h1>📖 Novo Testamento</h1>
                <p>Em ordem cronológica de escrita</p>
                ${vodHTML}
            </div>
            ${lastReadHTML}
            <div class="grid-2">
                <div class="quick-btn" onclick="Router.go('/livros')">
                    <span class="ico">📚</span><span class="lbl">Livros</span>
                </div>
                <div class="quick-btn" onclick="Router.go('/busca')">
                    <span class="ico">🔍</span><span class="lbl">Buscar</span>
                </div>
                <div class="quick-btn" onclick="Router.go('/favoritos')">
                    <span class="ico">⭐</span><span class="lbl">Favoritos</span>
                </div>
                <div class="quick-btn" onclick="Router.go('/anotacoes')">
                    <span class="ico">📝</span><span class="lbl">Anotações</span>
                </div>
            </div>
            <h3 class="section-title">Primeiros livros escritos</h3>
            ${Data.getAll().slice(0, 5).map(renderBookCard).join('')}
        `;
    }

    function renderBookCard(b, i) {
        const ordem = i !== undefined ? i + 1 : b.ordem_cronologica;
        return `
            <div class="book-card" onclick="Router.go('/book/${b.abbrev}')">
                <div class="book-num">${ordem}</div>
                <div class="book-info">
                    <div class="book-name">${esc(b.nome)}</div>
                    <div class="book-meta">
                        <span>${esc(b.ano)}</span>
                        <span>${esc(b.autor)}</span>
                        <span>${b.num_capitulos} cap.</span>
                    </div>
                </div>
            </div>`;
    }

    // ============ LIVROS ============
    function livros() {
        setTitle('Livros (Cronológico)');
        const all = Data.getAll();
        return `
            <p class="muted small" style="margin-bottom:12px">
                Os 27 livros do Novo Testamento organizados pela ordem aproximada de escrita.
                Os primeiros foram cartas como Tiago e Gálatas; o último, o Apocalipse.
            </p>
            ${all.map(renderBookCard).join('')}
        `;
    }

    // ============ DETALHE DO LIVRO (lista de capítulos) ============
    function book(params) {
        const b = Data.getBook(params.abbrev);
        if (!b) return `<div class="empty-state"><h3>Livro não encontrado</h3></div>`;
        setTitle(b.nome);
        const lastRead = Storage.getLastRead();
        const lastCh = (lastRead && lastRead.abbrev === b.abbrev) ? lastRead.chapter : null;

        const chapters = Array.from({ length: b.num_capitulos }, (_, i) => i + 1)
            .map(n => `
                <button class="chapter-btn ${n === lastCh ? 'last-read' : ''}"
                        onclick="Router.go('/chapter/${b.abbrev}/${n}')">${n}</button>
            `).join('');

        return `
            <div class="book-header">
                <h2>${esc(b.nome)}</h2>
                <div class="badges">
                    <span class="badge">${esc(b.ano)}</span>
                    <span class="badge">${esc(b.autor)}</span>
                    <span class="badge">#${b.ordem_cronologica} cronológico</span>
                </div>
                <p class="desc">${esc(b.evento)}</p>
            </div>
            <h3 class="section-title">Capítulos</h3>
            <div class="chapters-grid">${chapters}</div>
        `;
    }

    // ============ LEITURA DE CAPÍTULO ============
    function chapter(params) {
        const b = Data.getBook(params.abbrev);
        const ch = parseInt(params.chapter);
        const chapter = Data.getChapter(params.abbrev, ch);
        if (!b || !chapter) return `<div class="empty-state"><h3>Capítulo não encontrado</h3></div>`;

        setTitle(`${b.nome} ${ch}`);
        Storage.setLastRead(params.abbrev, ch, 0);
        Storage.pushHistory(params.abbrev, ch);

        const highlights = Storage.getHighlights();
        const notes = Storage.getNotes();
        const favs = Storage.getFavorites();

        const verses = chapter.map((text, i) => {
            const vNum = i + 1;
            const key = `${params.abbrev}_${ch}_${vNum}`;
            const hl = highlights[key];
            const hasNote = !!notes[key];
            const isFav = favs.some(f => f.abbrev === params.abbrev && f.chapter === ch && f.verse === vNum);
            const cls = [
                'verse',
                hl ? 'highlight-' + hl : '',
                hasNote ? 'has-note' : '',
                isFav ? 'is-fav' : ''
            ].filter(Boolean).join(' ');
            return `
                <div class="${cls}" data-v="${vNum}" onclick="App.openVerse('${params.abbrev}', ${ch}, ${vNum})">
                    <span class="verse-num">${vNum}</span><span class="verse-body">${esc(text)}</span>
                </div>`;
        }).join('');

        const { prev, next } = Data.getNeighbors(params.abbrev, ch);
        const navHTML = `
            <div class="chapter-nav">
                <button class="btn-nav ${!prev ? 'disabled' : ''}"
                    onclick="${prev ? `Router.go('/chapter/${prev.abbrev}/${prev.chapter}')` : ''}">
                    ← ${prev ? esc(prev.nome) + ' ' + prev.chapter : 'Início'}
                </button>
                <button class="btn-nav ${!next ? 'disabled' : ''}"
                    onclick="${next ? `Router.go('/chapter/${next.abbrev}/${next.chapter}')` : ''}">
                    ${next ? esc(next.nome) + ' ' + next.chapter : 'Fim'} →
                </button>
            </div>`;

        return `
            <div class="chapter-text">
                <div class="chapter-title">${esc(b.nome)} ${ch}</div>
                <div class="chapter-subtitle">${esc(b.ano)} • ${esc(b.autor)}</div>
                ${verses}
                ${navHTML}
            </div>
        `;
    }

    // ============ BUSCA ============
    function busca() {
        setTitle('Buscar');
        return `
            <div class="search-box">
                <input type="search" class="search-input" id="searchInput"
                       placeholder="Buscar palavra, frase ou referência (ex: João 3:16)" autocomplete="off" />
            </div>
            <p class="muted small" id="searchHint">Digite ao menos 2 caracteres.</p>
            <div id="searchResults"></div>
        `;
    }

    function attachSearch() {
        const inp = $('#searchInput');
        const hint = $('#searchHint');
        const results = $('#searchResults');
        if (!inp) return;
        inp.focus();
        let timer;
        inp.addEventListener('input', (e) => {
            clearTimeout(timer);
            const q = e.target.value.trim();
            if (q.length < 2) {
                hint.textContent = 'Digite ao menos 2 caracteres.';
                results.innerHTML = '';
                return;
            }
            timer = setTimeout(() => {
                const ref = Search.parseReference(q);
                if (ref && ref.book && ref.chapter) {
                    hint.innerHTML = `📖 Referência detectada: <strong>${esc(ref.book.nome)} ${ref.chapter}${ref.verse ? ':'+ref.verse : ''}</strong>`;
                    results.innerHTML = `
                        <div class="search-result" onclick="Router.go('/chapter/${ref.book.abbrev}/${ref.chapter}')">
                            <div class="ref">Abrir ${esc(ref.book.nome)} ${ref.chapter}</div>
                            <div class="text">Toque para abrir o capítulo</div>
                        </div>
                        <p class="section-title">Resultados de texto</p>
                    `;
                }
                const found = Search.searchText(q, 150);
                hint.textContent = `${found.length} resultado(s)` + (found.length >= 150 ? ' (limitado)' : '');
                const html = found.map(r => `
                    <div class="search-result" onclick="Router.go('/chapter/${r.abbrev}/${r.chapter}')">
                        <div class="ref">${esc(r.ref)}</div>
                        <div class="text">${r.highlighted}</div>
                    </div>`).join('');
                results.innerHTML = (results.innerHTML.includes('section-title') ? results.innerHTML : '') + html;
            }, 220);
        });
    }

    // ============ FAVORITOS ============
    function favoritos() {
        setTitle('Favoritos');
        const favs = Storage.getFavorites().slice().reverse();
        if (!favs.length) return emptyState('⭐', 'Nenhum favorito ainda', 'Toque em um versículo durante a leitura e marque como favorito.');

        return favs.map(f => {
            const b = Data.getBook(f.abbrev);
            if (!b) return '';
            const text = f.verse ? Data.getVerse(f.abbrev, f.chapter, f.verse) : '';
            const ref = `${b.nome} ${f.chapter}${f.verse ? ':' + f.verse : ''}`;
            return `
                <div class="list-item" onclick="Router.go('/chapter/${f.abbrev}/${f.chapter}')">
                    <div class="ref">⭐ ${esc(ref)}</div>
                    ${text ? `<div class="text">${esc(text)}</div>` : ''}
                    <div class="meta">${new Date(f.ts).toLocaleDateString('pt-BR')}</div>
                </div>`;
        }).join('');
    }

    // ============ ANOTAÇÕES ============
    function anotacoes() {
        setTitle('Anotações');
        const notes = Object.values(Storage.getNotes()).sort((a,b) => b.ts - a.ts);
        if (!notes.length) return emptyState('📝', 'Nenhuma anotação ainda', 'Toque em um versículo e escolha "Anotar" para criar suas reflexões.');

        return notes.map(n => {
            const b = Data.getBook(n.abbrev);
            if (!b) return '';
            const ref = `${b.nome} ${n.chapter}:${n.verse}`;
            const verseText = Data.getVerse(n.abbrev, n.chapter, n.verse) || '';
            return `
                <div class="list-item" onclick="Router.go('/chapter/${n.abbrev}/${n.chapter}')">
                    <div class="ref">📝 ${esc(ref)}</div>
                    <div class="text" style="font-style:italic; opacity:.85">"${esc(verseText.slice(0,120))}${verseText.length>120?'…':''}"</div>
                    <div class="text" style="margin-top:6px"><strong>${esc(n.text)}</strong></div>
                    <div class="meta">${new Date(n.ts).toLocaleDateString('pt-BR')}</div>
                </div>`;
        }).join('');
    }

    // ============ DESTAQUES ============
    function destaques() {
        setTitle('Destaques');
        const hls = Storage.getHighlights();
        const arr = Object.entries(hls).map(([k, color]) => {
            const [abbrev, ch, v] = k.split('_');
            return { abbrev, chapter: parseInt(ch), verse: parseInt(v), color };
        });
        if (!arr.length) return emptyState('🖍️', 'Nenhum destaque ainda', 'Toque em um versículo e escolha uma cor para destacar.');

        return arr.map(h => {
            const b = Data.getBook(h.abbrev);
            if (!b) return '';
            const text = Data.getVerse(h.abbrev, h.chapter, h.verse) || '';
            return `
                <div class="list-item highlight-${h.color}" style="border-left:4px solid ${colorHex(h.color)}"
                     onclick="Router.go('/chapter/${h.abbrev}/${h.chapter}')">
                    <div class="ref">${esc(b.nome)} ${h.chapter}:${h.verse}</div>
                    <div class="text">${esc(text)}</div>
                </div>`;
        }).join('');
    }

    function colorHex(c) {
        return { yellow:'#ffe680', green:'#9ee59e', blue:'#9ec6ff', pink:'#ffb3c1', orange:'#ffcc99' }[c] || '#ccc';
    }

    // ============ CONFIGURAÇÕES ============
    function configuracoes() {
        setTitle('Configurações');
        const s = Storage.getSettings();
        const themes = Themes.ALL.map(t => `
            <div class="theme-option t-${t.id} ${s.theme === t.id ? 'active' : ''}"
                 onclick="App.setTheme('${t.id}')">${esc(t.nome)}</div>
        `).join('');

        const fontSizes = [
            { id: 'small',  cls: 's1', lbl: 'A' },
            { id: 'medium', cls: 's2', lbl: 'A' },
            { id: 'large',  cls: 's3', lbl: 'A' },
            { id: 'xlarge', cls: 's4', lbl: 'A' }
        ].map(f => `
            <button class="font-size-btn ${f.cls} ${s.fontSize === f.id ? 'active' : ''}"
                    onclick="App.setFontSize('${f.id}')">${f.lbl}</button>
        `).join('');

        return `
            <div class="config-section">
                <h3>Tema</h3>
                <div class="theme-grid">${themes}</div>
            </div>
            <div class="config-section">
                <h3>Tamanho do texto</h3>
                <div class="font-sizes">${fontSizes}</div>
            </div>
            <div class="config-section">
                <h3>Dados</h3>
                <div class="config-item" onclick="App.exportData()">
                    <span class="label">📤 Exportar anotações/favoritos</span>
                </div>
                <div class="config-item" onclick="App.importData()">
                    <span class="label">📥 Importar backup</span>
                </div>
                <div class="config-item" onclick="App.clearData()">
                    <span class="label" style="color:#d44">🗑️ Apagar tudo</span>
                </div>
            </div>
            <div class="config-section">
                <h3>Versão da Bíblia</h3>
                <div class="config-item">
                    <span class="label">Versão atual</span>
                    <span class="value">Almeida Atualizada (domínio público)</span>
                </div>
                <p class="muted small" style="padding:10px 16px 14px">
                    O app está preparado para importar outras versões via JSON ou SQLite no futuro.
                    O texto da KJF está sujeito a direitos autorais (BV Books) e deve ser inserido manualmente.
                </p>
            </div>
        `;
    }

    // ============ SOBRE ============
    function sobre() {
        setTitle('Sobre');
        return `
            <div class="about">
                <div class="about-logo">📖</div>
                <h2>Bíblia Cronológica</h2>
                <p class="version">Novo Testamento • v1.0.0</p>
                <p>Aplicativo dedicado à leitura do Novo Testamento na ordem aproximada
                em que os livros foram escritos historicamente.</p>
                <p>Texto bíblico: <strong>Almeida Atualizada</strong> (domínio público).</p>
                <p>Estrutura preparada para suporte a outras versões (KJF/ARC) via importação.</p>
                <p style="margin-top:24px; font-size:13px" class="muted">
                    Funciona 100% offline. Seus favoritos, anotações e destaques ficam salvos
                    apenas no seu dispositivo.
                </p>
                <p style="margin-top:24px; font-size:12px" class="muted">
                    "A graça de nosso Senhor Jesus Cristo seja com todos."<br>
                    — Apocalipse 22:21
                </p>
            </div>
        `;
    }

    // ============ Helpers ============
    function emptyState(ico, title, desc) {
        return `<div class="empty-state">
            <div class="ico">${ico}</div>
            <h3>${esc(title)}</h3>
            <p>${esc(desc)}</p>
        </div>`;
    }

    return {
        home, livros, book, chapter, busca, favoritos, anotacoes,
        destaques, configuracoes, sobre, attachSearch
    };
})();
