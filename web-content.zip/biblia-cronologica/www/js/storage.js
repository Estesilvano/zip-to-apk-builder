/* ============================================================
   Storage - Wrapper sobre localStorage com namespaces
   ============================================================ */
const Storage = (() => {
    const PREFIX = 'bc_nt_';
    const KEYS = {
        SETTINGS:    PREFIX + 'settings',
        LAST_READ:   PREFIX + 'last_read',
        FAVORITES:   PREFIX + 'favorites',
        NOTES:       PREFIX + 'notes',
        HIGHLIGHTS:  PREFIX + 'highlights',
        HISTORY:     PREFIX + 'history'
    };

    function get(key, fallback) {
        try {
            const v = localStorage.getItem(key);
            return v ? JSON.parse(v) : fallback;
        } catch (e) {
            console.error('Storage.get', e);
            return fallback;
        }
    }

    function set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (e) {
            console.error('Storage.set', e);
            return false;
        }
    }

    return {
        KEYS,

        // SETTINGS
        getSettings() {
            return get(KEYS.SETTINGS, {
                theme: 'amoled',
                fontSize: 'medium',
                lineHeight: 'normal'
            });
        },
        setSettings(s) { set(KEYS.SETTINGS, s); },
        updateSetting(k, v) {
            const s = this.getSettings();
            s[k] = v;
            this.setSettings(s);
        },

        // LAST READ
        getLastRead() { return get(KEYS.LAST_READ, null); },
        setLastRead(abbrev, chapter, scrollY = 0) {
            set(KEYS.LAST_READ, { abbrev, chapter, scrollY, ts: Date.now() });
        },

        // FAVORITES (array of {abbrev, chapter, verse?})
        getFavorites() { return get(KEYS.FAVORITES, []); },
        toggleFavorite(abbrev, chapter, verse = null) {
            const favs = this.getFavorites();
            const idx = favs.findIndex(f => f.abbrev === abbrev && f.chapter === chapter && f.verse === verse);
            if (idx >= 0) {
                favs.splice(idx, 1);
            } else {
                favs.push({ abbrev, chapter, verse, ts: Date.now() });
            }
            set(KEYS.FAVORITES, favs);
            return idx < 0; // true = adicionado
        },
        isFavorite(abbrev, chapter, verse = null) {
            return this.getFavorites().some(f => f.abbrev === abbrev && f.chapter === chapter && f.verse === verse);
        },

        // NOTES - { 'abbrev_chapter_verse': { text, ts } }
        getNotes() { return get(KEYS.NOTES, {}); },
        getNote(abbrev, chapter, verse) {
            const k = `${abbrev}_${chapter}_${verse}`;
            return this.getNotes()[k] || null;
        },
        setNote(abbrev, chapter, verse, text) {
            const notes = this.getNotes();
            const k = `${abbrev}_${chapter}_${verse}`;
            if (text && text.trim()) {
                notes[k] = { abbrev, chapter, verse, text: text.trim(), ts: Date.now() };
            } else {
                delete notes[k];
            }
            set(KEYS.NOTES, notes);
        },
        deleteNote(abbrev, chapter, verse) {
            const notes = this.getNotes();
            delete notes[`${abbrev}_${chapter}_${verse}`];
            set(KEYS.NOTES, notes);
        },

        // HIGHLIGHTS - { 'abbrev_chapter_verse': color }
        getHighlights() { return get(KEYS.HIGHLIGHTS, {}); },
        getHighlight(abbrev, chapter, verse) {
            return this.getHighlights()[`${abbrev}_${chapter}_${verse}`] || null;
        },
        setHighlight(abbrev, chapter, verse, color) {
            const h = this.getHighlights();
            const k = `${abbrev}_${chapter}_${verse}`;
            if (color && color !== 'clear') {
                h[k] = color;
            } else {
                delete h[k];
            }
            set(KEYS.HIGHLIGHTS, h);
        },

        // HISTORY (últimas 30 leituras)
        getHistory() { return get(KEYS.HISTORY, []); },
        pushHistory(abbrev, chapter) {
            let h = this.getHistory();
            h = h.filter(x => !(x.abbrev === abbrev && x.chapter === chapter));
            h.unshift({ abbrev, chapter, ts: Date.now() });
            if (h.length > 30) h.length = 30;
            set(KEYS.HISTORY, h);
        },

        // EXPORT / IMPORT - para backup
        exportAll() {
            return {
                settings:   this.getSettings(),
                lastRead:   this.getLastRead(),
                favorites:  this.getFavorites(),
                notes:      this.getNotes(),
                highlights: this.getHighlights(),
                history:    this.getHistory(),
                version: 1,
                exportedAt: new Date().toISOString()
            };
        },
        importAll(data) {
            if (!data || typeof data !== 'object') return false;
            if (data.settings)   set(KEYS.SETTINGS, data.settings);
            if (data.lastRead)   set(KEYS.LAST_READ, data.lastRead);
            if (data.favorites)  set(KEYS.FAVORITES, data.favorites);
            if (data.notes)      set(KEYS.NOTES, data.notes);
            if (data.highlights) set(KEYS.HIGHLIGHTS, data.highlights);
            if (data.history)    set(KEYS.HISTORY, data.history);
            return true;
        },
        clearAll() {
            Object.values(KEYS).forEach(k => localStorage.removeItem(k));
        }
    };
})();
