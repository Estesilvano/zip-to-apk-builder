/* ============================================================
   Router - SPA simples baseado em hash
   ============================================================ */
const Router = (() => {
    let _currentRoute = null;
    let _handlers = {};

    function parse(hash) {
        if (!hash || hash === '#' || hash === '#/') return { page: 'home', params: {} };
        const clean = hash.replace(/^#\/?/, '');
        const parts = clean.split('/');
        const page = parts[0] || 'home';
        const params = {};
        if (page === 'book' && parts[1]) params.abbrev = parts[1];
        if (page === 'chapter' && parts[1] && parts[2]) {
            params.abbrev = parts[1];
            params.chapter = parseInt(parts[2]);
        }
        return { page, params };
    }

    function go(route) {
        window.location.hash = route.startsWith('#') ? route : '#' + route;
    }

    function on(page, handler) {
        _handlers[page] = handler;
    }

    function navigate() {
        const route = parse(window.location.hash);
        _currentRoute = route;
        const handler = _handlers[route.page] || _handlers['home'];
        if (handler) {
            const content = document.getElementById('content');
            if (content) content.scrollTop = 0;
            handler(route.params);
        }
        // Atualiza menu ativo
        document.querySelectorAll('.drawer-menu li').forEach(li => {
            li.classList.toggle('active', li.dataset.page === route.page);
        });
    }

    function init() {
        window.addEventListener('hashchange', navigate);
        navigate();
    }

    function current() { return _currentRoute; }

    return { parse, go, on, init, navigate, current };
})();
