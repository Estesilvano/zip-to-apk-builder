/* ============================================================
   Themes - Aplica e gerencia temas
   ============================================================ */
const Themes = (() => {
    const ALL = [
        { id: 'light',      nome: 'Claro',          desc: 'Tema claro para dia',         icon: '☀️' },
        { id: 'sepia',      nome: 'Sépia/Pergaminho', desc: 'Tom quente, conforto',     icon: '📜' },
        { id: 'amoled',     nome: 'AMOLED',         desc: 'Preto puro, economiza bateria', icon: '🌑' },
        { id: 'hacker',     nome: 'Hacker / CMD',   desc: 'Terminal verde retrô',        icon: '💻' },
        { id: 'bluefilter', nome: 'Filtro Azul',    desc: 'Reduz luz azul (noite)',     icon: '🌙' }
    ];

    function apply(themeId) {
        const valid = ALL.find(t => t.id === themeId);
        const id = valid ? themeId : 'amoled';
        document.body.className = document.body.className
            .split(' ').filter(c => !c.startsWith('theme-')).join(' ');
        document.body.classList.add('theme-' + id);
        // Atualiza theme-color do navegador
        const colors = {
            light: '#ffffff', sepia: '#f4ecd8',
            amoled: '#000000', hacker: '#000000', bluefilter: '#1a1408'
        };
        let meta = document.querySelector('meta[name="theme-color"]');
        if (meta) meta.setAttribute('content', colors[id]);
    }

    function applyFontSize(size) {
        const valid = ['small', 'medium', 'large', 'xlarge'];
        const s = valid.includes(size) ? size : 'medium';
        document.body.setAttribute('data-font-size', s);
    }

    function init() {
        const s = Storage.getSettings();
        apply(s.theme);
        applyFontSize(s.fontSize);
    }

    return { ALL, apply, applyFontSize, init };
})();
