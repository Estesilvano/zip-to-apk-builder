/* ============================================================
   App - Orquestrador principal
   ============================================================ */
const App = (() => {

    const $ = (sel) => document.querySelector(sel);
    let _verseCtx = null;  // contexto do modal de versículo
    let _noteCtx = null;   // contexto do modal de nota

    // ============ Toast ============
    let _toastTimer = null;
    function toast(msg, ms = 2000) {
        const el = $('#toast');
        if (!el) return;
        el.textContent = msg;
        el.classList.remove('hidden');
        clearTimeout(_toastTimer);
        _toastTimer = setTimeout(() => el.classList.add('hidden'), ms);
    }

    // ============ Drawer ============
    function openDrawer()  { $('#drawer').classList.add('active'); $('#drawerOverlay').classList.add('active'); }
    function closeDrawer() { $('#drawer').classList.remove('active'); $('#drawerOverlay').classList.remove('active'); }

    // ============ Modal versículo ============
    function openVerse(abbrev, chapter, verse) {
        _verseCtx = { abbrev, chapter, verse };
        const book = Data.getBook(abbrev);
        const text = Data.getVerse(abbrev, chapter, verse);
        $('#verseRef').textContent = `${book.nome} ${chapter}:${verse}`;
        $('#verseText').textContent = text;

        // Atualiza estado dos botões
        const isFav = Storage.isFavorite(abbrev, chapter, verse);
        $('#btnFav').innerHTML = isFav
            ? '<span>⭐</span> Remover favorito'
            : '<span>⭐</span> Favoritar';

        const hasNote = !!Storage.getNote(abbrev, chapter, verse);
        $('#btnNote').innerHTML = hasNote
            ? '<span>📝</span> Editar nota'
            : '<span>📝</span> Anotar';

        $('#verseModal').classList.remove('hidden');
    }

    function closeModal(id) { $('#' + id).classList.add('hidden'); }

    // ============ Ações do versículo ============
    function applyHighlight(color) {
        if (!_verseCtx) return;
        const { abbrev, chapter, verse } = _verseCtx;
        Storage.setHighlight(abbrev, chapter, verse, color === 'clear' ? null : color);
        closeModal('verseModal');
        Router.navigate();
        toast(color === 'clear' ? 'Destaque removido' : 'Versículo destacado');
    }

    function toggleFav() {
        if (!_verseCtx) return;
        const { abbrev, chapter, verse } = _verseCtx;
        const added = Storage.toggleFavorite(abbrev, chapter, verse);
        closeModal('verseModal');
        Router.navigate();
        toast(added ? '⭐ Favoritado' : 'Favorito removido');
    }

    function openNote() {
        if (!_verseCtx) return;
        _noteCtx = { ..._verseCtx };
        const { abbrev, chapter, verse } = _verseCtx;
        const book = Data.getBook(abbrev);
        const text = Data.getVerse(abbrev, chapter, verse);
        const existing = Storage.getNote(abbrev, chapter, verse);

        $('#noteRef').textContent = `${book.nome} ${chapter}:${verse} — "${text.slice(0, 80)}${text.length > 80 ? '…' : ''}"`;
        $('#noteText').value = existing ? existing.text : '';
        $('#btnDeleteNote').style.display = existing ? '' : 'none';

        closeModal('verseModal');
        $('#noteModal').classList.remove('hidden');
        setTimeout(() => $('#noteText').focus(), 100);
    }

    function saveNote() {
        if (!_noteCtx) return;
        const { abbrev, chapter, verse } = _noteCtx;
        const text = $('#noteText').value.trim();
        Storage.setNote(abbrev, chapter, verse, text);
        closeModal('noteModal');
        Router.navigate();
        toast(text ? 'Anotação salva' : 'Anotação removida');
    }

    function deleteNote() {
        if (!_noteCtx) return;
        const { abbrev, chapter, verse } = _noteCtx;
        Storage.deleteNote(abbrev, chapter, verse);
        closeModal('noteModal');
        Router.navigate();
        toast('Anotação removida');
    }

    function copyVerse() {
        if (!_verseCtx) return;
        const { abbrev, chapter, verse } = _verseCtx;
        const book = Data.getBook(abbrev);
        const text = Data.getVerse(abbrev, chapter, verse);
        const full = `"${text}" — ${book.nome} ${chapter}:${verse}`;
        if (navigator.clipboard) {
            navigator.clipboard.writeText(full).then(() => toast('Copiado!'));
        } else {
            const ta = document.createElement('textarea');
            ta.value = full; document.body.appendChild(ta); ta.select();
            try { document.execCommand('copy'); toast('Copiado!'); } catch(e){}
            document.body.removeChild(ta);
        }
        closeModal('verseModal');
    }

    function shareVerse() {
        if (!_verseCtx) return;
        const { abbrev, chapter, verse } = _verseCtx;
        const book = Data.getBook(abbrev);
        const text = Data.getVerse(abbrev, chapter, verse);
        const full = `"${text}" — ${book.nome} ${chapter}:${verse}`;
        if (navigator.share) {
            navigator.share({ title: `${book.nome} ${chapter}:${verse}`, text: full }).catch(() => {});
        } else {
            copyVerse();
        }
        closeModal('verseModal');
    }

    // ============ Configurações ============
    function setTheme(id) {
        Themes.apply(id);
        Storage.updateSetting('theme', id);
        Router.navigate();
        toast('Tema aplicado');
    }
    function setFontSize(s) {
        Themes.applyFontSize(s);
        Storage.updateSetting('fontSize', s);
        Router.navigate();
    }

    function exportData() {
        const data = Storage.exportAll();
        const json = JSON.stringify(data, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'biblia-cronologica-backup-' + new Date().toISOString().slice(0,10) + '.json';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        URL.revokeObjectURL(url);
        toast('Backup gerado');
    }

    function importData() {
        const input = document.createElement('input');
        input.type = 'file'; input.accept = 'application/json,.json';
        input.onchange = (e) => {
            const file = e.target.files[0]; if (!file) return;
            const reader = new FileReader();
            reader.onload = (ev) => {
                try {
                    const data = JSON.parse(ev.target.result);
                    Storage.importAll(data);
                    Themes.init();
                    Router.navigate();
                    toast('Backup importado!');
                } catch (err) {
                    toast('Arquivo inválido');
                }
            };
            reader.readAsText(file);
        };
        input.click();
    }

    function clearData() {
        if (confirm('Apagar TODOS os dados (favoritos, anotações, destaques)? Esta ação não pode ser desfeita.')) {
            Storage.clearAll();
            Themes.init();
            Router.go('/home');
            toast('Dados apagados');
        }
    }

    // ============ Navegação capítulo (bottombar) ============
    function navChapter(dir) {
        const cur = Router.current();
        if (!cur || cur.page !== 'chapter') {
            const last = Storage.getLastRead();
            if (last) Router.go(`/chapter/${last.abbrev}/${last.chapter}`);
            else Router.go('/livros');
            return;
        }
        const { prev, next } = Data.getNeighbors(cur.params.abbrev, cur.params.chapter);
        const target = dir === 'prev' ? prev : next;
        if (target) Router.go(`/chapter/${target.abbrev}/${target.chapter}`);
    }

    // ============ Inicialização ============
    function setupRoutes() {
        const content = $('#content');
        function render(html) { content.innerHTML = html; }
        Router.on('home',           ()       => render(Pages.home()));
        Router.on('livros',         ()       => render(Pages.livros()));
        Router.on('book',           (p)      => render(Pages.book(p)));
        Router.on('chapter',        (p)      => render(Pages.chapter(p)));
        Router.on('busca',          ()       => { render(Pages.busca()); Pages.attachSearch(); });
        Router.on('favoritos',      ()       => render(Pages.favoritos()));
        Router.on('anotacoes',      ()       => render(Pages.anotacoes()));
        Router.on('destaques',      ()       => render(Pages.destaques()));
        Router.on('configuracoes',  ()       => render(Pages.configuracoes()));
        Router.on('sobre',          ()       => render(Pages.sobre()));
    }

    function setupListeners() {
        // Topbar
        $('#btnMenu').addEventListener('click', openDrawer);
        $('#btnSearch').addEventListener('click', () => Router.go('/busca'));
        $('#drawerOverlay').addEventListener('click', closeDrawer);

        // Drawer menu
        document.querySelectorAll('.drawer-menu li').forEach(li => {
            li.addEventListener('click', () => {
                Router.go('/' + li.dataset.page);
                closeDrawer();
            });
        });

        // Modais close
        document.querySelectorAll('[data-close]').forEach(b => {
            b.addEventListener('click', () => closeModal(b.dataset.close));
        });
        document.querySelectorAll('.modal-overlay').forEach(o => {
            o.addEventListener('click', (e) => { if (e.target === o) o.classList.add('hidden'); });
        });

        // Color palette
        document.querySelectorAll('.color-swatch').forEach(s => {
            s.addEventListener('click', () => applyHighlight(s.dataset.color));
        });

        // Verse actions
        $('#btnFav').addEventListener('click', toggleFav);
        $('#btnNote').addEventListener('click', openNote);
        $('#btnCopy').addEventListener('click', copyVerse);
        $('#btnShare').addEventListener('click', shareVerse);
        $('#btnSaveNote').addEventListener('click', saveNote);
        $('#btnDeleteNote').addEventListener('click', deleteNote);

        // Bottombar
        document.querySelectorAll('.bottom-btn').forEach(b => {
            const act = b.dataset.action;
            if (act === 'prev-chapter') b.addEventListener('click', () => navChapter('prev'));
            else if (act === 'next-chapter') b.addEventListener('click', () => navChapter('next'));
            else if (act === 'reading') b.addEventListener('click', () => {
                const last = Storage.getLastRead();
                if (last) Router.go(`/chapter/${last.abbrev}/${last.chapter}`);
                else Router.go('/livros');
            });
            else b.addEventListener('click', () => Router.go('/' + act));
        });

        // Hardware back (Cordova/Capacitor)
        document.addEventListener('backbutton', () => {
            if (!$('#verseModal').classList.contains('hidden')) { closeModal('verseModal'); return; }
            if (!$('#noteModal').classList.contains('hidden'))  { closeModal('noteModal'); return; }
            if ($('#drawer').classList.contains('active')) { closeDrawer(); return; }
            if (Router.current() && Router.current().page !== 'home') Router.go('/home');
            else if (navigator.app && navigator.app.exitApp) navigator.app.exitApp();
        }, false);
    }

    async function init() {
        // Aplica tema imediatamente
        Themes.init();

        // Splash status
        const status = $('#splashStatus');
        status.textContent = 'Carregando Novo Testamento...';

        // Carrega dados
        try {
            await Data.load();
        } catch (e) {
            status.textContent = 'Erro ao carregar a Bíblia';
            console.error(e);
            return;
        }

        status.textContent = 'Preparando interface...';

        // Setup
        setupRoutes();
        setupListeners();
        Router.init();

        // Esconde splash
        setTimeout(() => {
            $('#splash').classList.add('fadeout');
            $('#app').classList.remove('hidden');
            setTimeout(() => $('#splash').remove(), 500);
        }, 600);
    }

    // Espera deviceready se Cordova, ou DOMContentLoaded
    if (window.cordova) {
        document.addEventListener('deviceready', init, false);
    } else {
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', init);
        } else {
            init();
        }
    }

    return {
        openVerse, setTheme, setFontSize,
        exportData, importData, clearData,
        toast
    };
})();
