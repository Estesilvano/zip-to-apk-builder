Esta pasta será preenchida automaticamente quando você rodar 'cordova platform add android' ou 'npx cap add android'.
