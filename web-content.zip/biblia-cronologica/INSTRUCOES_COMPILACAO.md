# 🛠️ Instruções de Compilação - Bíblia Cronológica NT

Este projeto está pronto para ser compilado em APK de duas formas: **Cordova** ou **Capacitor**. Escolha o método de sua preferência. **Cordova é mais simples**, **Capacitor oferece integração mais moderna com Android Studio**.

---

## 📋 Pré-requisitos comuns

1. **Node.js** 18+ - [nodejs.org](https://nodejs.org/)
2. **Java JDK 17** - necessário para Android (Gradle 8+)
3. **Android Studio** com Android SDK
   - SDK Platform 34 (Android 14)
   - Build Tools 34.0.0+
   - Platform Tools mais recente
4. **Variáveis de ambiente**:
   ```bash
   export ANDROID_HOME=$HOME/Android/Sdk
   export PATH=$PATH:$ANDROID_HOME/platform-tools:$ANDROID_HOME/cmdline-tools/latest/bin
   export JAVA_HOME=/usr/lib/jvm/java-17-openjdk
   ```

---

## 🅰️ Método 1: Cordova (recomendado, mais simples)

### Passo 1 — Instalar Cordova globalmente

```bash
npm install -g cordova
```

### Passo 2 — Instalar dependências do projeto

```bash
cd biblia-cronologica
npm install
```

### Passo 3 — Adicionar plataforma Android

```bash
cordova platform add android@13
```

### Passo 4 — Verificar requisitos (opcional)

```bash
cordova requirements
```

Vai listar o que está OK e o que falta (Java, Android SDK, Gradle).

### Passo 5 — Gerar APK de DEBUG (não assinado, para testes)

```bash
cordova build android
```

O APK será gerado em:
```
platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

Instale no celular via USB:
```bash
adb install platforms/android/app/build/outputs/apk/debug/app-debug.apk
```

### Passo 6 — Gerar APK de RELEASE (para distribuição)

#### 6.1 Crie um keystore (apenas na primeira vez)

```bash
keytool -genkey -v -keystore biblia.keystore -alias biblia \
        -keyalg RSA -keysize 2048 -validity 10000
```

#### 6.2 Crie um arquivo `build.json` na raiz do projeto

```json
{
  "android": {
    "release": {
      "keystore": "./biblia.keystore",
      "storePassword": "SUA_SENHA",
      "alias": "biblia",
      "password": "SUA_SENHA",
      "keystoreType": ""
    }
  }
}
```

#### 6.3 Compile o APK release

```bash
cordova build android --release
```

APK final em:
```
platforms/android/app/build/outputs/apk/release/app-release.apk
```

---

## 🅱️ Método 2: Capacitor (Android Studio integrado)

### Passo 1 — Instalar dependências

```bash
cd biblia-cronologica
npm install
```

### Passo 2 — Adicionar plataforma Android

```bash
npx cap add android
```

Isso vai criar a pasta `android/` com o projeto Gradle completo.

### Passo 3 — Copiar arquivos web para o projeto Android

```bash
npx cap sync android
```

### Passo 4 — Abrir no Android Studio

```bash
npx cap open android
```

### Passo 5 — Gerar APK pelo Android Studio

1. No menu: **Build** → **Generate Signed Bundle / APK**
2. Escolha **APK**
3. Crie ou selecione seu keystore
4. Escolha **release** e **V1+V2 signing**
5. Clique em **Finish**

O APK ficará em `android/app/release/app-release.apk`.

---

## 📂 Importando para o Android Studio diretamente (sem Capacitor)

Se quiser apenas abrir o projeto Cordova:

1. Compile uma vez: `cordova build android`
2. No Android Studio: **File** → **Open** → selecione `platforms/android/`
3. Sincronize o Gradle
4. **Build** → **Build APK(s)**

---

## 🧪 Teste rápido sem compilar (no navegador)

```bash
# Inicie um servidor local
npx http-server www -p 8080 -c-1

# Ou com Python:
python3 -m http.server 8080 --directory www
```

Abra `http://localhost:8080` no navegador. **Tudo funciona offline depois do primeiro carregamento.**

---

## 🔧 Solução de problemas comuns

### "SDK location not found"
Crie `local.properties` em `platforms/android/`:
```
sdk.dir=/caminho/para/Android/Sdk
```

### "Gradle build failed"
- Verifique o JDK: deve ser **Java 17**
- Limpe o cache: `cd platforms/android && ./gradlew clean`

### "Unable to delete file" no Windows
- Feche o Android Studio antes de rodar `cordova build`

### App abre branco
- Inspecione no Chrome: `chrome://inspect` (com USB debugging ativo)
- Verifique se `www/data/nt_cronologico.json` está incluído no build

### Texto não aparece
- Verifique no DevTools se `data/nt_cronologico.json` está sendo carregado (status 200)

---

## 📱 Instalação direta no celular (sem compilar)

Se você já tem o APK gerado:

1. Habilite **Fontes desconhecidas** no Android
2. Transfira o APK para o celular (USB, e-mail, nuvem)
3. Abra o APK e toque em **Instalar**

---

## 🎯 Checklist final antes de publicar

- [ ] Substituir versão da bíblia (se desejar usar KJF/ARC oficial)
- [ ] Atualizar `config.xml` com seu próprio `id` (ex: `com.seunome.biblia`)
- [ ] Substituir ícones em `resources/android/icon/` se quiser personalizar
- [ ] Assinar com seu keystore antes de publicar
- [ ] Testar em pelo menos 2 dispositivos (1 Android antigo + 1 moderno)

---

## 💬 Suporte

Em caso de dúvida sobre o código, leia os comentários dos arquivos em `www/js/` — todos foram comentados para facilitar manutenção.
