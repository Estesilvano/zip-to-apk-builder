# 📖 Bíblia Cronológica - Novo Testamento

> Aplicativo Android híbrido (Cordova + Capacitor) com o **Novo Testamento em ordem cronológica de escrita**, leitura offline, anotações, destaques, favoritos e 5 temas visuais.

---

## ✨ Características

- **27 livros do Novo Testamento** ordenados pela data aproximada em que foram escritos (de Tiago, ~45 d.C., a Apocalipse, ~95 d.C.)
- **100% offline** — todo o texto fica no dispositivo
- **5 temas visuais**: Claro, Sépia/Pergaminho, AMOLED puro, Hacker/CMD (verde terminal), Filtro de luz azul
- **4 tamanhos de fonte** ajustáveis
- **Sistema de busca** rápido (texto + referências como "João 3:16")
- **Anotações** vinculadas a versículos (editar/excluir)
- **Destaques coloridos** (amarelo, verde, azul, rosa, laranja)
- **Favoritos** de capítulos e versículos
- **Salvamento automático** da última leitura
- **Splash screen** elegante e ícones em todas as densidades
- **Suporte a back button** físico do Android
- **Compatível com Android 5.1+ (API 22+)**, otimizado para celulares simples

---

## 📁 Estrutura do projeto

```
biblia-cronologica/
├── config.xml                  # Configuração Cordova
├── capacitor.config.json       # Configuração Capacitor
├── package.json                # Dependências + scripts
├── README.md                   # Este arquivo
├── INSTRUCOES_COMPILACAO.md    # Passo a passo para gerar APK
├── resources/
│   └── android/
│       ├── icon/               # Ícones em todas as densidades (ldpi → xxxhdpi)
│       └── splash/             # Splash screens
└── www/                        # CÓDIGO DO APP (raiz do webview)
    ├── index.html              # HTML principal
    ├── manifest.json           # PWA manifest
    ├── css/
    │   ├── main.css            # Reset, layout, splash
    │   ├── themes.css          # 5 temas
    │   └── components.css      # Componentes UI
    ├── js/
    │   ├── storage.js          # localStorage (notas, destaques, favoritos)
    │   ├── themes.js           # Sistema de temas
    │   ├── data.js             # Carregamento da Bíblia
    │   ├── search.js           # Motor de busca
    │   ├── router.js           # SPA router (hash-based)
    │   ├── pages.js            # Renderização de páginas
    │   └── app.js              # Orquestrador / handlers
    ├── data/
    │   ├── nt_cronologico.json # NT completo em ordem cronológica (~780 KB)
    │   └── nt_indice.json      # Índice rápido (apenas metadados)
    └── assets/
        ├── icons/              # Ícones PWA
        ├── img/                # Imagens diversas
        └── fonts/              # (pasta preparada para fontes customizadas)
```

---

## 📚 Versão bíblica utilizada

Por padrão o app usa a **Almeida Atualizada (aa)**, que é uma versão clássica em **domínio público** distribuída via [thiagobodruk/biblia](https://github.com/thiagobodruk/biblia).

### Para usar a KJF (King James Fiel)

A KJF possui direitos vinculados à **BV Books**. Você pode:

1. **Substituir o JSON**: Mantenha o formato `[{ "abbrev": "mt", "chapters": [["v1","v2",...],...] }, ...]` e edite os textos no arquivo `www/data/nt_cronologico.json`.
2. **Importar de SQLite**: O código está preparado em `js/data.js` para receber uma função `loadFromSQLite()` futura. Use o plugin `cordova-sqlite-storage` ou `@capacitor-community/sqlite`.

### Para usar a ARC ou ACF

```bash
# Baixe o JSON desejado:
curl -L https://raw.githubusercontent.com/thiagobodruk/biblia/master/json/acf.json -o aa.json
# E execute build_nt.py novamente (incluso na raiz do projeto)
python3 build_nt.py
```

---

## 🛠️ Instruções de compilação

Veja o arquivo **`INSTRUCOES_COMPILACAO.md`** para o passo a passo completo.

### Resumo rápido (Cordova)

```bash
npm install -g cordova
cd biblia-cronologica
npm install
cordova platform add android
cordova build android --release
# APK em: platforms/android/app/build/outputs/apk/release/
```

### Resumo rápido (Capacitor)

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android   # Abre Android Studio para gerar o APK
```

### Teste no navegador (sem Android Studio)

```bash
npx http-server www -p 8080 -c-1
# Abra http://localhost:8080 no navegador
```

---

## 🎨 Temas inclusos

| ID | Nome | Quando usar |
|----|------|-------------|
| `light` | Claro | Dia, ambiente bem iluminado |
| `sepia` | Sépia/Pergaminho | Conforto visual, estilo livro antigo |
| `amoled` | AMOLED puro | Telas AMOLED, economia máxima de bateria |
| `hacker` | Hacker / CMD | Verde terminal `#0a0a0a` + `#00ff0a`, estilo retro-tech |
| `bluefilter` | Filtro azul | Noite, antes de dormir |

---

## 🗓️ Ordem cronológica adotada

A ordem segue o consenso acadêmico moderado, levando em conta data aproximada de **escrita** (não de eventos):

1. Tiago (~45-49 d.C.)
2. Gálatas (~49 d.C.)
3. 1 Tessalonicenses (~51 d.C.)
4. 2 Tessalonicenses (~51-52 d.C.)
5. 1 Coríntios (~55 d.C.)
6. 2 Coríntios (~56 d.C.)
7. Romanos (~57 d.C.)
8. Marcos (~50-60 d.C.)
9. Mateus (~60-65 d.C.)
10. Lucas (~60-65 d.C.)
11. Atos (~62-63 d.C.)
12. Hebreus (~64-68 d.C.)
13-16. Efésios, Filipenses, Colossenses, Filemom (~60-62 d.C., cartas da prisão)
17-19. 1 Timóteo, Tito, 2 Timóteo (~62-67 d.C., pastorais)
20-21. 1 Pedro, 2 Pedro (~62-68 d.C.)
22. Judas (~65-80 d.C.)
23. João (~85-95 d.C.)
24-26. 1 João, 2 João, 3 João (~90-95 d.C.)
27. Apocalipse (~95-96 d.C.)

> _A datação exata varia entre eruditos. Os anos exibidos são representativos._

---

## 📜 Licença

- **Código do app**: MIT
- **Texto bíblico Almeida Atualizada**: Domínio público
- **Ícones e splash**: Criados especificamente para este projeto

---

## 🙏 Créditos

- Texto bíblico: [thiagobodruk/biblia](https://github.com/thiagobodruk/biblia)
- Ordenação cronológica baseada em consensos acadêmicos publicados
